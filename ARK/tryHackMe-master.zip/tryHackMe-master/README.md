# tryHackMe
This where my Cyber Security knownledge will live. This will show process and certifications involving hacking.


------------------------------------------------------------------------------------------------------------------------
                                                Certifications Completed
------------------------------------------------------------------------------------------------------------------------
            
1. Pre Security Certification     : https://tryhackme-certificates.s3-eu-west-1.amazonaws.com/THM-AMTA5CF8XW.png
2. Introduction to Cyber Security : https://tryhackme-certificates.s3-eu-west-1.amazonaws.com/THM-WA4ZDEKAMD.png

------------------------------------------------------------------------------------------------------------------------
                                              In progress for Certifications
-------------------------------------------------------------------------------------------------------------------------

1. Introduction to Cyber Security 
2. Jr Penetration Tester

------------------------------------------------------------------------------------------------------------------------
                                                Cyber Security Path Shown
------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------
            Original Overview of the Pathway                 |                Recommended Pathway to take                    
------------------------------------------------------------------------------------------------------------------------

                Pre Security                                                      Pre Security
                Jr Penetration Tester                                             Introduction to Cyber Security
                Offensive Pentesting                                              Jr Penetration Tester
                    
