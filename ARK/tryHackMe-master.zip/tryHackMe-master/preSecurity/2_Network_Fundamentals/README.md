-----------------------------------------------------------------------------------------------------------------------------------							
|							# Order List of Reading							  |	
-----------------------------------------------------------------------------------------------------------------------------------

	Titles of Files	        ->  		Description of the title 

-----------------------------------------------------------------------------------------------------------------------------------
1. network			-> Learning the core concepts of how computers communicate with each other and type of network weaknesses.	
2. intro_to_lan			-> Technologies and designs that power private networks
3. OSI_Model 			-> Fundamental networking framework that determines the various stages in which data is handle across network
4. Packets_and_Frames		-> Understand how data is divided into pieces and transmitted across netowork to another device.
5. Extending_Your_Netowrk	-> Technologies used to extend networks out onto the Internet and the motivations for this.


