
1.  Windows_part1	Start with learning of Windows desktop, the NTFs file 
			system, UAC, the control Panel , etc

2.  Windows_part2	Discover more about System Configuration, UAC Settings,
			Resource Monitoring, the windows Registry...

3.  Windows_part3	Learn about the built-in Microsoft tools that help keep
			the device secure, such as Windows Update, Window Security
			Bitlocker and more...


