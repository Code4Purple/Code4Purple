-----------------------------------------------------------------------------------
				Order Listing of Reading
-----------------------------------------------------------------------------------

Order		Tilte of File			->	Description


-----------------------------------------------------------------------------------
1. 		DNS_in_detail 			->	How DNS works and how it helps you access internet services.
2. 		HTTP_in_detail			->	How you request content from a web server using the HTTP protocol
3. 		How_websites_work		->	To exploit a website, you first need to know they are created.
4.		Putting_it_all_together		->	How all the individual components of the web work together to bring you access to your favourite web.
5.		how_the_internet_works		-> 	The order of the process the browser and websites go through in order to make the internet works in today's world.
